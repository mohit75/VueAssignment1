// routes.js
import Vue from 'vue';
import Router from 'vue-router';
import Help from './components/Help.vue';
import HelloWorld from './components/HelloWorld.vue';

Vue.use(Router);

const routes = [
    { path: '/help', name:"help", component: Help },
    { path: '/helloWorld', name:"helloWorld",component: HelloWorld },
];

export default routes;