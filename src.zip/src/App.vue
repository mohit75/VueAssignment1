<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <h1 msg="Welcome to Your Vue.js Demo App"/>
    <nav>
      <router-link to='/help'>Help Page</router-link>
    </nav>
     <router-view /> 
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
