<template>
    <h1>Welcome to the Vue World</h1>
</template>
